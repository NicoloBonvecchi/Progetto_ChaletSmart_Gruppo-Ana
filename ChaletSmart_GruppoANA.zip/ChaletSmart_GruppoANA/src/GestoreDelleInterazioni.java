import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import javax.xml.crypto.Data;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.account.TipoAccount;
import it.unicam.cs.chaletsmart.persone.Cliente;
import it.unicam.cs.chaletsmart.persone.PersonaChaletSmart;
import it.unicam.cs.chaletsmart.serviziospiaggia.Ombrellone;
import it.unicam.cs.chaletsmart.serviziospiaggia.Prenotazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.RincaroStagione;
import it.unicam.cs.chaletsmart.serviziospiaggia.Spiaggia;
import it.unicam.cs.chaletsmart.serviziospiaggia.TipoCollocazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.TipoPrenotazione;

public class GestoreDelleInterazioni {

	//private ArrayList<Account> listaAccountTerminaleGenerale;
	private Set<PersonaChaletSmart> listaUtenti;
	private Spiaggia spiaggia;
	public void avvia()
	{
		spiaggia = new Spiaggia("si", "si",10);
		Ombrellone o = new Ombrellone(1, "ombrellone 1", 1, TipoCollocazione.AVANTI, 0);
		Ombrellone o2 = new Ombrellone(2, "ombrellone 2", 2, TipoCollocazione.AVANTI, 0);
		spiaggia.aggiungiOmbrellone(o);
		spiaggia.aggiungiOmbrellone(o2);
		listaUtenti=new HashSet<PersonaChaletSmart>();
		Account a = new Account("mario", "mail", "password");
		a.setTipoAccount(TipoAccount.ACCOUNTAMMINISTRATORE);
		Account account=null;
		boolean esciDalCiclo=false;
		Scanner reader = new Scanner(System.in);
		int scelta=-2;
		int indice=0;
		while (!esciDalCiclo) 
		{
			System.out.println("[INFO] Benvenuti allo Chalet Smart");
			System.out.println("[INFO] Scegli il tipo di account con cui accedere:");			
			for (indice=0; indice<TipoAccount.values().length; indice++)
				System.out.println("[INFO] Scegli " + indice + " per accedere come " + TipoAccount.values()[indice].getStringaAssociata());
			
			System.out.println("[INFO] Scegli " + indice++ + " per Creare un nuovo Account Cliente");
			System.out.println("[INFO] Scegli -1 per uscire");
			
			/**
			 * Controllo se viene inserito un intero
			 */
			if(reader.hasNextInt())
			{
				scelta = reader.nextInt();
			}
			else
				reader.nextLine();
			
			/**
			 * Se la scelta ricade in uno dei valori proposti (che vanno da 0 al 
			 * numero di account disponibili)
			 */
			if(scelta>=0 && scelta<TipoAccount.values().length)
			{
				account = login(TipoAccount.values()[scelta]);
				if(account==null)
					System.out.println("[INFO] Nome utente o password errata");
				else
				{
					System.out.println("[INFO] Login effettuato correttamente in qualita' di : "+TipoAccount.values()[scelta].getStringaAssociata());
					break;
				}
			}
			
			/**
			 * Se la scelta e' quella di creare un nuovo account Cliente
			 */
			else if(scelta==TipoAccount.values().length)
			{
				this.creaAccountCliente();
			}
			
			/**
			 * Se la scelta e' di uscire dal ciclo
			 */
			else if(scelta==-1)
				esciDalCiclo=true;
			else
				System.out.println("[INFO] Scelta non valida");
		}
		
		if(account!=null && account.getTipoAccount()!=null)
		{
			switch (account.getTipoAccount()) {
			case ACCOUNTUTENTESTANDARD:
				this.accediFunzionalitaUtenteStandard(account);
				break;
			case ACCOUNTAMMINISTRATORE:
				
				break;
			case ACCOUNTADDETTOATTIVITA:
				
			break;
			case ACCOUNTADDETTOBARCASSA:
				
				break;
			case ACCOUNTADDETTOPRENOTAZIONI:
				break;
			}
		}
		
		
		reader.close();
	}
	
	private Account login(TipoAccount tipoAccount)
	{
		String nome;
		String password;
		Scanner reader = new Scanner(System.in);
		
		//Credenziali utente
		System.out.println("[REQS] Inserire username");
		nome=reader.nextLine();
		System.out.println("[REQS] Inserire password");
		password=reader.nextLine();
		
		//Controllo account
		for(PersonaChaletSmart persona: this.listaUtenti)
		{
			for(Account account : persona.getAccount())
				if(account.getTipoAccount()!=null &&
				   account.getTipoAccount().equals(tipoAccount)
				   && account.getNomeUtente().compareTo(nome)==0)
						if(account.controllaPassword(password))
							return account;
		}
		return null;
	}
	
	private void creaAccountCliente() 
	{
		String nome;
		String cognome;
		String password;
		String email;
		String dataNascita;
		String telefono;
		String userName;
		Scanner reader = new Scanner(System.in);
		
		//Credenziali utente
		System.out.println("[REQS] Inserire nome");
		nome=reader.nextLine();
		System.out.println("[REQS] Inserire cognome");
		cognome=reader.nextLine();
		System.out.println("[REQS] Inserire data di nascita");
		dataNascita=reader.nextLine();
		System.out.println("[REQS] Inserire numero di telefono");
		telefono=reader.nextLine();
		System.out.println("[REQS] Inserire user name");
		userName=reader.nextLine();
		System.out.println("[REQS] Inserire email");
		email=reader.nextLine();
		System.out.println("[REQS] Inserire password");
		password=reader.nextLine();
		
		Account account = new Account(userName, email, password);
		account.setTipoAccount(TipoAccount.ACCOUNTUTENTESTANDARD);
		Cliente cliente=new Cliente(nome, cognome , dataNascita, telefono);
		if(this.listaUtenti.contains(cliente))
		{
			for(PersonaChaletSmart c: this.listaUtenti)
				if(c.equals(cliente))
					c.aggiungiAccount(account);
		}
		else
		{
			cliente.aggiungiAccount(account);
			this.listaUtenti.add(cliente);
		}

	}
	
	private void accediFunzionalitaUtenteStandard(Account account)
	{
		PersonaChaletSmart persona;
		String scelta;
		do 
		{
			Scanner reader = new Scanner(System.in);
			System.out.println("[INFO] Scegli 0 per prenotare un Ombrellone");
			System.out.println("[INFO] Scegli 1 per prenotare un'attivita'");
			System.out.println("[INFO] Scegli 2 per creare un'ordinazione");
			System.out.println("[INFO] Scegli 3 per rimuovere una prenotazione spiaggia");
			System.out.println("[INFO] Scegli 4 per rimuovere una prenotazione attivita'");
			System.out.println("[INFO] Scegli 5 per rimuovere un'ordinazione");
			System.out.println("[INFO] Scegli 6 per visualizzare le tue prenotazioni");
			System.out.println("[INFO] Scegli -1 per uscire dalla sezione utente standard");
			
			scelta = reader.nextLine();

			switch (scelta) {
			case "0":
				persona = trovaPersonadellAccount(account);
				if(persona instanceof Cliente)
					prenotaOmbrellone((Cliente)persona);
				break;
			case "6":
				persona = trovaPersonadellAccount(account);
				if(persona instanceof Cliente)
					this.visualizzaPrenotazioniDelCliente((Cliente)persona);
			break;
			default:
				break;
			}
		}while(true);
	}
	
	private PersonaChaletSmart trovaPersonadellAccount(Account account)
	{
		for(PersonaChaletSmart persona:this.listaUtenti)
			for(Account a:persona.getAccount())
				if(a.equals(account))
					return persona;
		
		return null;
	}
	private void prenotaOmbrellone(Cliente cliente)
	{
		Prenotazione prenotazione;
		int continuareAdAggiungereOmbrelloni=0;
		Date data = specificaData();
		Scanner reader = new Scanner(System.in);
		ArrayList<Ombrellone>ombrelloniTrovati = new ArrayList<Ombrellone>();
		ArrayList<Ombrellone>ombrelloniScelti = new ArrayList<Ombrellone>();
		boolean trovatoOccupato = false;
		int idOmbrelloneScelto = -2;
		System.out.println("[INFO] Quale ombrellone vuoi prenotare");
		/**
		 * Trovo tutti gli ombrelloni disponibili per la data specificata
		 */
		for(Ombrellone o:spiaggia.getElencoOmbrelloni())
		{
			trovatoOccupato = false;
			for(Prenotazione p: spiaggia.getTabellaPrenotazioni())
			{
				if(p.getGiornoDellaPrenotazione().getDay()==data.getDay() &&
				   p.getGiornoDellaPrenotazione().getMonth()==data.getMonth() &&
				   p.getGiornoDellaPrenotazione().getYear()==data.getYear())
					for(Ombrellone ombrellone:p.getOmbrelloniAssociati())
					{
						if(ombrellone.equals(o))
							trovatoOccupato =true;
					}
			}
			/**
			 * Se trovo un ombrellone non occupato, in quella data,
			 *  lo aggiungo all'elenco degli ombrelloni trovati
			 */
			if(!trovatoOccupato)
			{
				ombrelloniTrovati.add(o);
			}
		}
		if(ombrelloniTrovati.size()>0)
		{
		
			boolean idTrovato=false;
			do 
			{
				if(ombrelloniTrovati.size()>0)
				{
					System.out.println("[INFO] Ombrelloni ancora disponibili :\n");
					for(Ombrellone o : ombrelloniTrovati)
						System.out.println("[INFO] " + o.toString() + "\n");
				}
	
				idTrovato=false;
				while(!idTrovato && ombrelloniTrovati.size()>0 && idOmbrelloneScelto!=-1)
				{
					idTrovato = false;
					System.out.println("[REQS] Inserire l'id dell'ombrellone desiderato o -1 PER ANNULLARE");
					if(reader.hasNextInt())
					{
						idOmbrelloneScelto = reader.nextInt();
						for(Ombrellone o:ombrelloniTrovati)
							if(o.getId()==idOmbrelloneScelto)
							{
								idTrovato=true;
								ombrelloniScelti.add(o);
							}
					}
					if(!idTrovato)
					{
						reader.nextLine();
				        System.out.println("[INFO] ID NON PRESENTE\n");
					}
					idOmbrelloneScelto=-2;
				}
				if(ombrelloniScelti.size()>0)
				{
					System.out.println("\n[INFO] Hai selezionato i seguenti ombrelloni : ");
					for(Ombrellone o : ombrelloniScelti)
					{
						System.out.println(o.toString() + "\n");
					}
					System.out.println("\n[REQS] Vuoi aggiungere altri ombrelloni?\n-1 : SI\n-2 : NO");
					if(reader.hasNextInt())
					{
						continuareAdAggiungereOmbrelloni = reader.nextInt();
					}
					if(continuareAdAggiungereOmbrelloni<0 && continuareAdAggiungereOmbrelloni>2)
					{
						reader.nextLine();
				        System.out.println("[INFO] SCELTA NON VALIDA");
						continue;
					}
					
					ombrelloniTrovati.remove(ombrelloniScelti.get(ombrelloniScelti.size()-1));
				}
			}while(continuareAdAggiungereOmbrelloni!=2 && ombrelloniTrovati.size()>0);
			
			if(ombrelloniTrovati.size()==0 && continuareAdAggiungereOmbrelloni==1)
				System.out.println("[INFO] NON CI SONO PIU' OMBRELLONI DISPONIBILI");
			
			TipoPrenotazione tipoPrenotazione;
			System.out.println("[REQS] Scegli il tipo di prenotazione\n-1 : MEZZA GIORNTA\n-Digita qualsiasi altra cosa per GIORNATA INTERA");
			reader.nextLine();
			String appTipoPrenotazione = reader.nextLine();
			tipoPrenotazione = ((appTipoPrenotazione.equals("1")) ? TipoPrenotazione.MEZZAGIORNATA : TipoPrenotazione.INTERO);
			
			boolean veritas=false;
			int numeroLettini=0;
			do
			{
				System.out.println("[REQS] Inserisci numeri di lettini da prenotare");
				
				if(reader.hasNextInt())
				{
					numeroLettini=reader.nextInt();
					if(numeroLettini>=0)
						veritas=true;
				}
				else
					reader.nextLine();
				
				if(!veritas)
					System.out.println("[INFO] Numero di lettini NON CORRETTO");
			}while(!veritas);

			/**
			 * Controllo se il cliente ha gia prenotazioni consecutive
			 */
			for(Prenotazione p : spiaggia.getTabellaPrenotazioni())
			{
				if(p.getClientePrenotante().equals(cliente))
				{
					if(p.getGiornoDellaPrenotazione().after(data) || 
						p.getGiornoDellaPrenotazione().before(data))
						p.setAGiorniConsecutivi(true);
				}
			}
			Ombrellone[] ombrelloniSceltiDaPassareAPrenotazione = new Ombrellone[ombrelloniScelti.size()];
			for(int i=0;i<ombrelloniScelti.size();i++)
				ombrelloniSceltiDaPassareAPrenotazione[i]=ombrelloniScelti.get(i);
			prenotazione = new Prenotazione(cliente, tipoPrenotazione, ombrelloniSceltiDaPassareAPrenotazione, numeroLettini , data);
			this.spiaggia.aggiungiPrenotazione(prenotazione);
		}
		/**
		 * Altrimenti se per il giorno specificato non ci sono ombrelloni disponibili
		 */
		else
		{
	        System.out.println("[INFO] Ci rincresce, la spiaggia, per il giorno specificato, risulta al completo");
		}
		
	}
	
	private Date specificaData()
	{
		Date data = new Date();
		Scanner reader = new Scanner(System.in);
		int giorno;
		int mese;
		int anno;
		boolean meseTrovato;
		while(true)
		{
			meseTrovato=false;
			reader = new Scanner(System.in);
			System.out.println("[REQS] Per quale giorno vuoi prenotare");
			if(reader.hasNextInt())
			{
				giorno = reader.nextInt();
			}
			else
			{
				reader.nextLine();
		        System.out.println("[INFO] Giorno NON CORRETTO, riprovare\n");
				continue;
			}
			System.out.println("[REQS] Per quale mese vuoi prenotare");
			if(reader.hasNextInt())
			{
				mese = reader.nextInt();
				for(RincaroStagione r:RincaroStagione.values())
				{
					if(mese==r.getMese())
					{
						meseTrovato=true;
					}
				}
				
				if(!meseTrovato)
				{
			        System.out.println("[INFO] Spiaggia CHIUSA nel mese specificato\n");
					continue;
				}
			}
			else
			{
				reader.nextLine();
		        System.out.println("[INFO] Mese NON CORRETTO, riprovare\n");
				continue;
			}
			System.out.println("[REQS] Per quale anno vuoi prenotare");
			if(reader.hasNextInt())
			{
				anno = reader.nextInt();
			}
			else
			{
				reader.nextLine();
		        System.out.println("[INFO] Anno NON CORRETTO, riprovare\n");
				continue;
			}

			if(!convalidaData(new String(mese+"/"+giorno+"/"+anno)))
				continue;
			else 
			{
				mese--;
				data.setDate(giorno);
				data.setMonth(mese);
				data.setYear(anno-1900);
				Date dataOggi = new Date();
				if(data.before(dataOggi))
				{
					System.out.println("[INFO] La data della prenotazione DEVE ESSERE successiva a quella odierna");
					continue;
				}
				return data;

			}
		}
	}

   private  boolean convalidaData(String strData)
   {
		if (strData.trim().equals(""))
		    return true;
		else
		{
		    SimpleDateFormat sdfrmt = new SimpleDateFormat("MM/dd/yyyy");
		    sdfrmt.setLenient(false);
		    try
		    {
		        Date javaDate = sdfrmt.parse(strData); 
		    }
		    catch (ParseException e)
		    {
		        System.out.println("[INFO] Formato data NON CORRETTO, riprovare\n");
		        return false;
		    }
		    return true;
		}
   }
	
   private void visualizzaPrenotazioniDelCliente(Cliente cliente)
   {
	   System.out.println("[INFO] Le tue prenotazioni sono : ");
	   for(Prenotazione p : spiaggia.getTabellaPrenotazioni())
	   {
		   if(p.getClientePrenotante().equals(cliente))
		   {
			   System.out.println(p.toString());
		   }
	   }
		
   }
}
