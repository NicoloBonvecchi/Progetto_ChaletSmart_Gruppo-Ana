import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.account.TipoAccount;
import it.unicam.cs.chaletsmart.persone.Cliente;
import it.unicam.cs.chaletsmart.persone.PersonaChaletSmart;

public class GestoreDelleInterazioni {

	//private ArrayList<Account> listaAccountTerminaleGenerale;
	private HashMap<PersonaChaletSmart, Account> listaAccountTerminaleGenerale;

	public void avvia()
	{
		listaAccountTerminaleGenerale=new HashMap<>();
		
		Account a = new Account("mario", "mail", "password");
		a.setTipoAccount(TipoAccount.ACCOUNTAMMINISTRATORE);
		
		Account account;
		boolean esciDalCiclo=false;
		Scanner reader = new Scanner(System.in);
		int scelta=-2;
		int indice=0;
		while (!esciDalCiclo) 
		{
			System.out.println("[INFO] Benvenuti allo Chalet Smart");
			System.out.println("[INFO] Scegli il tipo di account con cui accedere:");			
			for (indice=0; indice<TipoAccount.values().length; indice++)
				System.out.println("[INFO] Scegli " + indice + " per Creare un nuovo " + TipoAccount.values()[indice].getStringaAssociata());
			
			System.out.println("[INFO] Scegli " + indice++ + " per Creare un nuovo Account Cliente");
			System.out.println("[INFO] Scegli -1 per uscire");
			
			/**
			 * Controllo se viene inserito un intero
			 */
			if(reader.hasNextInt())
			{
				scelta = reader.nextInt();
			}
			else
				reader.nextLine();
			
			/**
			 * Se la scelta ricade in uno dei valori proposti (che vanno da 0 al 
			 * numero di account disponibili)
			 */
			if(scelta>=0 && scelta<TipoAccount.values().length)
			{
				account = login(TipoAccount.values()[scelta]);
				if(account==null)
					System.out.println("[INFO] Nome utente o password errata");
				else
				{
					System.out.println("[INFO] Login effettuato correttamente in qualita' di : "+TipoAccount.values()[scelta].getStringaAssociata());
					break;
				}
			}
			
			/**
			 * Se la scelta e' quella di creare un nuovo account Cliente
			 */
			else if(scelta==TipoAccount.values().length)
			{
				//crea nuovo account
				break;
			}
			
			/**
			 * Se la scelta e' di uscire dal ciclo
			 */
			else if(scelta==-1)
				esciDalCiclo=true;
			else
				System.out.println("[INFO] Scelta non valida");
		}
		reader.close();
	}
	
	private Account login(TipoAccount tipoAccount)
	{
		String nome;
		String password;
		Scanner reader = new Scanner(System.in);
		
		//Credenziali utente
		System.out.println("[INFO] Inserire username");
		nome=reader.nextLine();
		System.out.println("[INFO] Inserire password");
		password=reader.nextLine();
		
		//Controllo account
		for(Account account: this.listaAccountTerminaleGenerale.values())
		{
			if(account.getTipoAccount().equals(tipoAccount)
					&& account.getNomeUtente().compareTo(nome)==0)
						 if(account.controllaPassword(password))
							 return account;
		}
		return null;
	}
	
	private void creaAccountCliente() 
	{
		String nome;
		String cognome;
		String password;
		String email;
		String dataNascita;
		String telefono;
		String userName;
		Scanner reader = new Scanner(System.in);
		
		//Credenziali utente
		System.out.println("[INFO] Inserire nome");
		nome=reader.nextLine();
		System.out.println("[INFO] Inserire cognome");
		cognome=reader.nextLine();
		System.out.println("[INFO] Inserire data di nascita");
		dataNascita=reader.nextLine();
		System.out.println("[INFO] Inserire numero di telefono");
		telefono=reader.nextLine();
		System.out.println("[INFO] Inserire numero di userName");
		userName=reader.nextLine();
		System.out.println("[INFO] Inserire email");
		email=reader.nextLine();
		System.out.println("[INFO] Inserire password");
		password=reader.nextLine();
		
		Account account = new Account(userName, email, password);
		Cliente cliente=new Cliente(nome, cognome , dataNascita, telefono, account);
		this.listaAccountTerminaleGenerale.put(cliente, account);
	}
}
