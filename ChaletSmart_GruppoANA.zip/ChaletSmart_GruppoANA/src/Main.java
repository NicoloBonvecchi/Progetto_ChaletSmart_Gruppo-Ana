
import java.util.Date;
import java.util.Scanner;

import javax.security.auth.login.LoginContext;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.persone.Cliente;
import it.unicam.cs.chaletsmart.persone.Gestore;
import it.unicam.cs.chaletsmart.serviziobar.Ordinazione;
import it.unicam.cs.chaletsmart.serviziobar.Piatto;
import it.unicam.cs.chaletsmart.serviziospiaggia.Ombrellone;
import it.unicam.cs.chaletsmart.serviziospiaggia.Prenotazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.Spiaggia;
import it.unicam.cs.chaletsmart.serviziospiaggia.TipoCollocazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.TipoPrenotazione;

public class Main {

	private Ordinazione[] listaOrdinazioni;
	private Prenotazione[] listaprenotazioni;

	public static void main(String args[])
	{
		GestoreDelleInterazioni g = new GestoreDelleInterazioni();
		g.avvia();
	}
	
	
		
}