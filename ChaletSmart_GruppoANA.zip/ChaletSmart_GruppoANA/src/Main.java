
import java.util.Date;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.persone.Cliente;
import it.unicam.cs.chaletsmart.serviziobar.Ordinazione;
import it.unicam.cs.chaletsmart.serviziobar.Piatto;
import it.unicam.cs.chaletsmart.serviziospiaggia.Ombrellone;
import it.unicam.cs.chaletsmart.serviziospiaggia.Prenotazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.Spiaggia;
import it.unicam.cs.chaletsmart.serviziospiaggia.TipoCollocazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.TipoPrenotazione;

public class Main {

	private Account[] listaAccountTerminaleGenerale;
	private Ordinazione[] listaOrdinazioni;
	private Prenotazione[] listaprenotazioni;

	public static void main(String args[])
	{
		Ombrellone o = new Ombrellone(2, "desc", 0, TipoCollocazione.AVANTI, 1);
		Ombrellone[] ombrelloniAssociati = {o};
		Account account = new Account("Mario", "mail", "password");
		Cliente cliente = new Cliente("Mario", "Rossi","si", "Si", account);
		Date d = new Date();
		d.setMonth(6);
		d.setYear(1998);
		d.setDate(3);
		Date d1 = new Date();
		d1.setMonth(5);
		d1.setYear(2021);
		Date d2 = new Date();
		d1.setMonth(8);
		d1.setYear(2021);
		Prenotazione p = new Prenotazione(cliente, TipoPrenotazione.INTERO, ombrelloniAssociati, 3, d);
		Prenotazione p2 = new Prenotazione(cliente, TipoPrenotazione.INTERO, ombrelloniAssociati, 3, d1);

		Spiaggia s = new Spiaggia("2", "2", 1);
		if(!s.aggiungiPrenotazione(p))
			System.out.println("Pieno");
		s.aggiungiPrenotazione(p2);
		float app =s.getRincaroMedioPrenotazioneDelCliente(cliente);
		System.out.println(app);
		System.out.println(s.getNumeroTotaleOmbrelloniPrenotatiPerData(d2));
		System.out.println(d.toString());
		Ordinazione ordinazione = new Ordinazione(cliente,o);
		Piatto piatto = new Piatto(0,"s", "pasta", 2, "si", "anche", "pure");
		ordinazione.aggiungiProdottiAdElencoProdotti(piatto, 1);
	}
}