import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Date;

import it.unicam.cs.chaletsmart.gestionedatabase.DBManager;

public class Main {

	public static void main(String args[])
	{
		
		GestoreDelleInterazioni gestoreDelleInterazioni = new GestoreDelleInterazioni();
		gestoreDelleInterazioni.avvia();
	}
}