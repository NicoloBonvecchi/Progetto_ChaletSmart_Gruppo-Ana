import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import it.unicam.cs.chaletsmart.account.Account;

public class Main {

	public static void main(String args[])
	{
		GestoreDelleInterazioni g = new GestoreDelleInterazioni();
		Account a = new Account("si", "si", "si");
        Gson gson = new Gson();
        String jsonString = gson.toJson(a);
        System.out.println("Json"+jsonString);
		g.avvia();
		

       
	}

}