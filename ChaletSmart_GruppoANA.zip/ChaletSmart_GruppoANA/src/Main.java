

public class Main {

	public static void main(String args[])
	{
		
		GestoreDelleInterazioni gestoreDelleInterazioni = new GestoreDelleInterazioni();
		gestoreDelleInterazioni.avvia();
	}
}