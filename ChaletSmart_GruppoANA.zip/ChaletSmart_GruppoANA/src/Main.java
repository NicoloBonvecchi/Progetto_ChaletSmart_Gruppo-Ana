
import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.serviziobar.Ordinazione;
import it.unicam.cs.chaletsmart.serviziospiaggia.Prenotazione;

public class Main {

	private Account[] listaAccountTerminaleGenerale;
	private Ordinazione[] listaOrdinazioni;
	private Prenotazione[] listaprenotazioni;

	public static void main(String args[])
	{

	}
}