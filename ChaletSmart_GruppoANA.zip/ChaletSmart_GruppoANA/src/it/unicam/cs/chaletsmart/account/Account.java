package it.unicam.cs.chaletsmart.account;

public class Account {

	private String nomeUtente;
	private String email;
	private String password;
	private TipoAccount tipoAccount;

	/**
	 * 
	 * @param nomeUtente
	 * @param email
	 * @param password
	 */
	public Account(String nomeUtente, String email, String password) {
		this.nomeUtente=nomeUtente;
		this.email=email;
		this.password=password;
	}

	public String getNomeUtente() {
		return this.nomeUtente;
	}

	/**
	 * 
	 * @param nomeUtente
	 */
	public void setNomeUtente(String nomeUtente) {
		this.nomeUtente = nomeUtente;
	}

	public String getEmail() {
		return this.email;
	}

	/**
	 * 
	 * @param email
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * 
	 * @param password
	 */
	public Boolean controllaPassword(String password) {
		return this.password==password;
	}

	/**
	 * 
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	public TipoAccount getTipoAccount() {
		return this.tipoAccount;
	}

	/**
	 * 
	 * @param tipoAccount
	 */
	public void setTipoAccount(TipoAccount tipoAccount) {
		this.tipoAccount = tipoAccount;
	}

}