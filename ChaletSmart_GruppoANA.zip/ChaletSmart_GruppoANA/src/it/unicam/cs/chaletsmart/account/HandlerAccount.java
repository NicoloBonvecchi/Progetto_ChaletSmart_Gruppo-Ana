package it.unicam.cs.chaletsmart.account;

public class HandlerAccount {
}