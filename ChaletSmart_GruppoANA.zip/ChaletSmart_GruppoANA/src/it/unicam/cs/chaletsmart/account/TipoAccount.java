package it.unicam.cs.chaletsmart.account;

public enum TipoAccount {
	ACCOUNTUTENTESTANDARD,
	ACCOUNTADDETTOPRENOTAZIONI,
	ACCOUNTADDETTOATTIVITA,
	ACCOUNTADDETTOBARCASSA,
	ACCOUNTAMMINISTRATORE;

	private String StringaAssociata;

	public String getStringaAssociata() {
		return this.StringaAssociata;
	}

	/**
	 * 
	 * @param StringaAssociata
	 */
	public void setStringaAssociata(String StringaAssociata) {
		this.StringaAssociata = StringaAssociata;
	}

}