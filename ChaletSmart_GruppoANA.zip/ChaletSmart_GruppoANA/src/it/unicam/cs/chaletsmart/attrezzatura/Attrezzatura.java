package it.unicam.cs.chaletsmart.attrezzatura;

public class Attrezzatura {

	private int idTipoAttrezzatura;
	/**
	 * Rappresenta la quantita' complessiva di un dato tipo di attrezzatura
	 */
	private int quantita;
	private String descrizione;

	/**
	 * 
	 * @param idTipoAttrezzatura
	 * @param quantita
	 * @param descrizione
	 */
	public Attrezzatura(int idTipoAttrezzatura, int quantita, String descrizione) {
		this.idTipoAttrezzatura=idTipoAttrezzatura;
		this.quantita=quantita;
		this.descrizione=descrizione;
	}

	public int getIdTipoAttrezzatura() {
		return this.idTipoAttrezzatura;
	}

	/**
	 * 
	 * @param idTipoAttrezzatura
	 */
	public void setIdTipoAttrezzatura(int idTipoAttrezzatura) {
		this.idTipoAttrezzatura = idTipoAttrezzatura;
	}

	public int getQuantita() {
		return this.quantita;
	}

	/**
	 * 
	 * @param quantita
	 */
	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}

	public String getDescrizione() {
		return this.descrizione;
	}

	/**
	 * 
	 * @param descrizione
	 */
	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

}