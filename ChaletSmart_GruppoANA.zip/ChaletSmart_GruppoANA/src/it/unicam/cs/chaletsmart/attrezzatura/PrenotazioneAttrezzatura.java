package it.unicam.cs.chaletsmart.attrezzatura;

import it.unicam.cs.chaletsmart.persone.*;

public class PrenotazioneAttrezzatura {

	private int idTipoAttrezzatura;
	private String oraInizioPrenotazione;
	/**
	 * L'ora della restituzione non sar� specificata quando si prenotano le attrezzature, bens� solo al momento della restituzione di quest'ultime.
	 */
	private String oraRestituzione;
	private AddettoAttivita addettoAttivita;
	private int quantitaAttrezzaturaPrenotata;

	/**
	 * 
	 * @param idTipoAttrezzatura
	 * @param quantitaAttrezzaturaPrenotata
	 * @param oraInizioPrenotazione
	 * @param addettoAttivita
	 */
	public PrenotazioneAttrezzatura(int idTipoAttrezzatura, int quantitaAttrezzaturaPrenotata, String oraInizioPrenotazione, AddettoAttivita addettoAttivita) {
		// TODO - implement PrenotazioneAttrezzatura.PrenotazioneAttrezzatura
		throw new UnsupportedOperationException();
	}

	public int getIdTipoAttrezzatura() {
		return this.idTipoAttrezzatura;
	}

	/**
	 * 
	 * @param idTipoAttrezzatura
	 */
	public void setIdTipoAttrezzatura(int idTipoAttrezzatura) {
		this.idTipoAttrezzatura = idTipoAttrezzatura;
	}

	public int getQuantitaAttrezzaturaPrenotata() {
		return this.quantitaAttrezzaturaPrenotata;
	}

	/**
	 * 
	 * @param quantitaAttrezzaturaPrenotata
	 */
	public void setQuantitaAttrezzaturaPrenotata(int quantitaAttrezzaturaPrenotata) {
		this.quantitaAttrezzaturaPrenotata = quantitaAttrezzaturaPrenotata;
	}

	public String getOraInizioPrenotazione() {
		return this.oraInizioPrenotazione;
	}

	/**
	 * 
	 * @param oraInizioPrenotazione
	 */
	public void setOraInizioPrenotazione(String oraInizioPrenotazione) {
		this.oraInizioPrenotazione = oraInizioPrenotazione;
	}

	public String getOraRestituzione() {
		return this.oraRestituzione;
	}

	/**
	 * 
	 * @param oraRestituzione
	 */
	public void setOraRestituzione(String oraRestituzione) {
		this.oraRestituzione = oraRestituzione;
	}

	public AddettoAttivita getAddettoAttivita() {
		return this.addettoAttivita;
	}

	/**
	 * 
	 * @param addettoAttivita
	 */
	public void setAddettoAttivita(AddettoAttivita addettoAttivita) {
		this.addettoAttivita = addettoAttivita;
	}

}