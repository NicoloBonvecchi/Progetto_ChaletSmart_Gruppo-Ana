package it.unicam.cs.chaletsmart.gestionedatabase;

import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.account.TipoAccount;
import it.unicam.cs.chaletsmart.persone.AddettoAttivita;
import it.unicam.cs.chaletsmart.persone.AddettoBarCassa;
import it.unicam.cs.chaletsmart.persone.AddettoPrenotazioni;
import it.unicam.cs.chaletsmart.persone.Cliente;
import it.unicam.cs.chaletsmart.persone.Gestore;
import it.unicam.cs.chaletsmart.persone.PersonaChaletSmart;
import it.unicam.cs.chaletsmart.serviziospiaggia.Spiaggia;

public class DBManager 
{
	Connection conn = null;

	public DBManager(String url, String name, String password)
	{
		try 
		{
			Class.forName("org.postgresql.Driver");
		} 
		catch (ClassNotFoundException e)
		{
			System.out.println("Where is your PostgreSQL JDBC Driver? " + "Include in your library path!");
			e.printStackTrace();
		}	
		try 
		{
			conn = DriverManager.getConnection(url, name, password);
		}
		catch (Exception e) 
		{
			System.out.println("Problems in opening a connection to the DB");
			e.printStackTrace();
		}
	}
	
	public boolean isConnected() 
	{
		try
		{
			return !conn.isClosed();
		}
		catch (Exception e)
		{
			return false;
		}
	}
	
	public void caricaAccount(Account account,String password,PersonaChaletSmart persona)
	{
		String query;
		query = "insert into account (nomeutente,email,password,tipoaccount) values ('"+ 
		account.getNomeUtente()+"','"+account.getEmail()+"','"+password+"','"
		+account.getTipoAccount().getStringaAssociata()+"');";
		ResultSet resultSet;
		try
		{
			Statement statement = conn.createStatement();
			statement.execute(query);
		}
		catch(Exception e)
		{
			return;
		}
		
		query = "Select ID from account WHERE email= '"+account.getEmail()+"';";
		
		try
		{
			Statement statement = conn.createStatement();
			resultSet =statement.executeQuery(query);
			int appId;
			if(resultSet.next())
			{
				appId=resultSet.getInt(1);
				query = "Update personachaletsmart Set accountid= "+appId+" WHERE nome = '"+persona.getNome()+"'and cognome = '"+
				persona.getCognome()+"'and datanascita = '"+persona.getDataN()+"'and telefono = '"+persona.getTel()+"';";
				statement.execute(query);
			}
		}
		catch (Exception e) 
		{
		}
		
	}
	public void caricaPersona(PersonaChaletSmart persona)
	{
		String query;
		try
		{
			query = "insert into personachaletsmart (nome,cognome,datanascita,telefono) values ('"+ 
					persona.getNome()+"','"+persona.getCognome()+"','"+persona.getDataN()+"','"
					+persona.getTel()+"');";
			Statement statement = conn.createStatement();
			statement.execute(query);
		}
		catch (Exception e) 
		{
			return;
		}
		
	}

	public ArrayList<PersonaChaletSmart> inizializzaListaUtenti(Spiaggia spiaggia)
	{
		ArrayList<PersonaChaletSmart> risultato = new ArrayList<PersonaChaletSmart>();
		String queryPersone = "select * from personachaletsmart;";
		try
		{
			Statement statement = conn.createStatement();
			Statement statement2 = conn.createStatement();

			ResultSet resultPersona = statement.executeQuery(queryPersone);
			String queryAccount;
			while(resultPersona.next())
			{
				int appIdAccount = resultPersona.getInt(6);
				String appNome = resultPersona.getString(2);
				String appCognome = resultPersona.getString(3);
				String appDataNascita = resultPersona.getString(4);
				String appTelefono = resultPersona.getString(5);
				
				queryAccount = "Select * from account where id = "+appIdAccount +";";
				ResultSet resultAccount = statement2.executeQuery(queryAccount);
				Account appAccount = null;
				String tipoAccount=null;

				if(resultAccount.next())
				{
					appAccount = new Account(resultAccount.getString(2), resultAccount.getString(3), resultAccount.getString(4));
					tipoAccount = resultAccount.getString(5);
				}
				
				if(tipoAccount!=null)
				{
					switch(tipoAccount)
					{
						case "Cliente":
							risultato.add(new Cliente(appNome, appCognome, appDataNascita, appTelefono));
							appAccount.setTipoAccount(TipoAccount.ACCOUNTUTENTESTANDARD);
							risultato.get(risultato.size()-1).setAccount(appAccount);
							break;
						case "Addetto Prenotazioni":
							risultato.add(new AddettoPrenotazioni(appNome, appCognome, appDataNascita, appTelefono));
							appAccount.setTipoAccount(TipoAccount.ACCOUNTADDETTOPRENOTAZIONI);
							risultato.get(risultato.size()-1).setAccount(appAccount);
							break;
						case "Addetto Attivita":
							risultato.add(new AddettoAttivita(appNome, appCognome, appDataNascita, appTelefono));
							appAccount.setTipoAccount(TipoAccount.ACCOUNTADDETTOATTIVITA);
							risultato.get(risultato.size()-1).setAccount(appAccount);
							break;
						case "Addetto Bar Cassa":
							risultato.add(new AddettoBarCassa(appNome, appCognome, appDataNascita, appTelefono));
							appAccount.setTipoAccount(TipoAccount.ACCOUNTADDETTOBARCASSA);
							risultato.get(risultato.size()-1).setAccount(appAccount);
							break;
						case "Gestore":
							risultato.add(new Gestore(appNome, appCognome, appDataNascita, appTelefono,spiaggia));
							appAccount.setTipoAccount(TipoAccount.ACCOUNTAMMINISTRATORE);
							risultato.get(risultato.size()-1).setAccount(appAccount);
							break;
					}
				}
				else
					risultato.add(new Cliente(appNome, appCognome, appDataNascita, appTelefono));
			}
		}
		catch (Exception e) {
			System.out.println(e.toString());
		}
		
		return risultato;
	}
	
	public void cambiaDataInizio(String dataInizio)
	{
		String query = "select * from menu";
		int appId;
		try
		{
			Statement statement = conn.createStatement();
			ResultSet resultSet = statement.executeQuery(query);
			resultSet.last();
			appId=resultSet.getInt(1);
			statement.execute("UPDATE menu SET datainizio=tua data WHERE id= "+appId+";");
		}
		catch(Exception e)
		{
			return;
		}
	}
}
