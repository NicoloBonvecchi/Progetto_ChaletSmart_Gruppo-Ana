package it.unicam.cs.chaletsmart.persone;

import java.util.ArrayList;
import java.util.Arrays;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.attrezzatura.*;
import it.unicam.cs.chaletsmart.serviziospiaggia.*;

public class AddettoAttivita extends PersonaChaletSmart {
	
	private ArrayList<PrenotazioneAttrezzatura> listaPrenotazioniAttrezzatura;

	public AddettoAttivita(String nome, String cognome, String dataNascita, String telefono) {
		super(nome, cognome, dataNascita, telefono);
		listaPrenotazioniAttrezzatura=new ArrayList<PrenotazioneAttrezzatura>();
	}


	public ArrayList<PrenotazioneAttrezzatura> getListaPrenotazioniAttrezzatura() {
		return new ArrayList<>(this.listaPrenotazioniAttrezzatura);
	}

	/**
	 * 
	 * @param listaPrenotazioniAttrezzatura
	 */
	public void setListaPrenotazioniAttrezzatura(PrenotazioneAttrezzatura[] listaPrenotazioniAttrezzatura) {
		this.listaPrenotazioniAttrezzatura.clear();
		this.listaPrenotazioniAttrezzatura.addAll(Arrays.asList(listaPrenotazioniAttrezzatura));
	}

	/**
	 * 
	 * @param attrezzatura
	 * @param oraInizioPrenotazione
	 */
	public void aggiungiPrenotazioneAttrezzatura(Attrezzatura attrezzatura, String oraInizioPrenotazione, int quantitaAttrezzaturaDaPrenotare) {
		this.listaPrenotazioniAttrezzatura.add(new PrenotazioneAttrezzatura(
				attrezzatura.getIdTipoAttrezzatura(),
				quantitaAttrezzaturaDaPrenotare,
				oraInizioPrenotazione, 
				this));
	}

	/**
	 * 
	 * @param attrezzatura
	 */
	public boolean rimuoviPrenotazioneAttrezzatura(PrenotazioneAttrezzatura prenotazioneAttrezzatura) {
		return listaPrenotazioniAttrezzatura.remove(prenotazioneAttrezzatura);
	}

	/**
	 * 
	 * @param attrezzatura
	 * @param oraRestituzione
	 */
	public boolean restituisciAttrezzatura(PrenotazioneAttrezzatura prenotazioneAttrezzatura, String oraRestituzione) {
		int indicePrenotazione = this.listaPrenotazioniAttrezzatura.indexOf(prenotazioneAttrezzatura);
		if(indicePrenotazione<0)
			return false;
		this.listaPrenotazioniAttrezzatura.get(indicePrenotazione).setOraRestituzione(oraRestituzione);
		return true;
	}

	/**
	 * 
	 * @param cliente
	 * @param attivita
	 */
	public boolean prenotaAttivitaPerCliente(Cliente cliente, Attivita attivita) {
		if(attivita.getPartecipanti().size()>=attivita.getCapienzaMax())
			return false;
		attivita.aggiungiPartecipante(cliente);
		return true;
	}
	
	public boolean rimuoviPrenotazioneAttivitaPerCliente(Cliente cliente, Attivita attivita)
	{
		return attivita.rimuoviPartecipante(cliente);
	}

}