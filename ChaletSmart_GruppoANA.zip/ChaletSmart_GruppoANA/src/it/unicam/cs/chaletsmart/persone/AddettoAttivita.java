package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.attrezzatura.*;
import it.unicam.cs.chaletsmart.serviziospiaggia.*;

public class AddettoAttivita extends PersonaChaletSmart {

	public AddettoAttivita(String nome, String cognome, String dataN, String tel) {
		super(nome, cognome, dataN, tel);
		// TODO Auto-generated constructor stub
	}

	private PrenotazioneAttrezzatura[] listaPrenotazioniAttrezzatura;

	public PrenotazioneAttrezzatura[] getListaPrenotazioniAttrezzatura() {
		return this.listaPrenotazioniAttrezzatura;
	}

	/**
	 * 
	 * @param listaPrenotazioniAttrezzatura
	 */
	public void setListaPrenotazioniAttrezzatura(PrenotazioneAttrezzatura[] listaPrenotazioniAttrezzatura) {
		this.listaPrenotazioniAttrezzatura = listaPrenotazioniAttrezzatura;
	}

	/**
	 * 
	 * @param attrezzatura
	 * @param oraInizioPrenotazione
	 */
	public void aggiungiPrenotazioneAttrezzatura(Attrezzatura attrezzatura, String oraInizioPrenotazione) {
		// TODO - implement AddettoAttivita.aggiungiPrenotazioneAttrezzatura
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param attrezzatura
	 */
	public boolean rimuoviPrenotazioneAttrezzatura(Attrezzatura attrezzatura) {
		// TODO - implement AddettoAttivita.rimuoviPrenotazioneAttrezzatura
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param attrezzatura
	 * @param oraRestituzione
	 */
	public void restituisciAttrezzatura(Attrezzatura attrezzatura, String oraRestituzione) {
		// TODO - implement AddettoAttivita.restituisciAttrezzatura
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param cliente
	 * @param attivita
	 */
	public boolean prenotaAttivitaPerCliente(Cliente cliente, Attivita attivita) {
		// TODO - implement AddettoAttivita.prenotaAttivitaPerCliente
		throw new UnsupportedOperationException();
	}

}