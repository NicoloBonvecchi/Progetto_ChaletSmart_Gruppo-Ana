package it.unicam.cs.chaletsmart.persone;

import java.util.ArrayList;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.serviziobar.*;

public class AddettoBarCassa extends PersonaChaletSmart {

	public AddettoBarCassa(String nome, String cognome, String dataNascita, String telefono, Account account) {
		super(nome, cognome, dataNascita, telefono, account);
	}

	/**
	 * 
	 * @param ordinazione
	 */
	public void creaOrdinazionePerCliente(Ordinazione ordinazione, ArrayList<Ordinazione> listaOrdinazioni) {
		listaOrdinazioni.add(ordinazione);
	}

	public boolean rimuoviOrdinazionePerCliente(Ordinazione ordinazione, ArrayList<Ordinazione> listaOrdinazioni) {
		return listaOrdinazioni.remove(ordinazione);
	}
}