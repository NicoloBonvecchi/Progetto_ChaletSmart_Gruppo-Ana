package it.unicam.cs.chaletsmart.persone;

import java.util.ArrayList;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.serviziobar.*;
import it.unicam.cs.chaletsmart.serviziospiaggia.Spiaggia;

public class AddettoBarCassa extends PersonaChaletSmart {

	public AddettoBarCassa(String nome, String cognome, String dataNascita, String telefono, Account account) {
		super(nome, cognome, dataNascita, telefono, account);
	}

	/**
	 * 
	 * @param ordinazione
	 */
	public void creaOrdinazionePerCliente(Ordinazione ordinazione, Spiaggia spiaggia) {
		spiaggia.aggiungiOrdinazione(ordinazione);
	}

	public boolean rimuoviOrdinazionePerCliente(Ordinazione ordinazione, Spiaggia spiaggia) {
		return spiaggia.rimuoviOrdinazione(ordinazione);
	}
}