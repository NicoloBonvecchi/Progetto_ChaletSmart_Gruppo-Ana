package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.serviziobar.*;

public class AddettoBarCassa extends PersonaChaletSmart {

	public AddettoBarCassa(String nome, String cognome, String dataN, String tel) {
		super(nome, cognome, dataN, tel);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param ordinazione
	 */
	public void creaOrdinazionePerCliente(Ordinazione ordinazione) {
		// TODO - implement AddettoBarCassa.creaOrdinazionePerCliente
		throw new UnsupportedOperationException();
	}

}