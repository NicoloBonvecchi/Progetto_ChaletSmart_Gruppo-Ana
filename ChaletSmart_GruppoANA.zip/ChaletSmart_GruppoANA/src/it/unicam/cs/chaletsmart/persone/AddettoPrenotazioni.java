package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.serviziospiaggia.*;

public class AddettoPrenotazioni extends PersonaChaletSmart {

	public AddettoPrenotazioni(String nome, String cognome, String dataN, String tel) {
		super(nome, cognome, dataN, tel);
		// TODO Auto-generated constructor stub
	}

	/**
	 * nel main attraverso un'apposita funzionalit� creeremo la prenotazione che poi verr� passata a questo metodo, il quale la memorizzer� opportunamente in Spiaggia
	 * @param prenotazione
	 */
	public boolean prenotaSpiaggiaPerCliente(Prenotazione prenotazione) {
		// TODO - implement AddettoPrenotazioni.prenotaSpiaggiaPerCliente
		throw new UnsupportedOperationException();
	}

}