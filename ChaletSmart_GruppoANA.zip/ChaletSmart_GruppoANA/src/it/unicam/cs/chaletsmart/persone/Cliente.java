package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.serviziospiaggia.*;
import it.unicam.cs.chaletsmart.serviziobar.*;

public class Cliente extends PersonaChaletSmart {

	public Cliente(String nome, String cognome, String dataN, String tel) {
		super(nome, cognome, dataN, tel);
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 * @param prenotazione
	 */
	public boolean prenotaSpiaggiaClienteSmart(Prenotazione prenotazione) {
		// TODO - implement Cliente.prenotaSpiaggiaClienteSmart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param attivita
	 */
	public boolean prenotaAttivitaClienteSmart(Attivita attivita) {
		// TODO - implement Cliente.prenotaAttivitaClienteSmart
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ordinazione
	 */
	public void creaOrdinazioneClienteSmart(Ordinazione ordinazione) {
		// TODO - implement Cliente.creaOrdinazioneClienteSmart
		throw new UnsupportedOperationException();
	}

}