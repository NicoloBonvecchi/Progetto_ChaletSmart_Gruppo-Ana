package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.serviziospiaggia.*;

import java.util.Date;

import it.unicam.cs.chaletsmart.account.Account;
import it.unicam.cs.chaletsmart.serviziobar.*;

public class Cliente extends PersonaChaletSmart {

	public Cliente(String nome, String cognome, String dataNascita, String telefono, Account account) {
		super(nome, cognome, dataNascita, telefono, account);
	}

	/**
	 * 
	 * @param prenotazione
	 */
	public boolean prenotaSpiaggiaClienteSmart(TipoPrenotazione tipoPrenotazione, Ombrellone[] ombrelloniAssociati, int lettiniAssociati, Date giornoDellaPrenotazione, Spiaggia spiaggia) {
		Prenotazione prenotazione = new Prenotazione(
				this,
				tipoPrenotazione,
				ombrelloniAssociati,
				lettiniAssociati,
				giornoDellaPrenotazione);
		return spiaggia.aggiungiPrenotazione(prenotazione);
	}

	/**
	 * 
	 * @param attivita
	 */
	public boolean prenotaAttivitaClienteSmart(Attivita attivita) {
		return attivita.aggiungiPartecipante(this);
	}

	/**
	 * 
	 * @param ordinazione
	 */
	public Ordinazione creaOrdinazioneClienteSmart(Ombrellone Ombrellone, Spiaggia spiaggia) {
		Ordinazione ordinazioneDaAggiungere=new Ordinazione(this, Ombrellone);
		spiaggia.aggiungiOrdinazione(ordinazioneDaAggiungere);
		return ordinazioneDaAggiungere;
	}

	public boolean rimuoviPrenotazioneSpaggiaSpecificaClienteSmart(Prenotazione prenotazione, Spiaggia spiaggia)
	{
		return spiaggia.rimuoviPrenotazione(prenotazione);
	}
}