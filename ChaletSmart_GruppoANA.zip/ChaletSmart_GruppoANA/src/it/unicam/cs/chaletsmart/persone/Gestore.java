package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.serviziospiaggia.*;

public class Gestore extends PersonaChaletSmart {


	private Spiaggia spiaggia;

	public Gestore(String nome, String cognome, String dataN, String tel,Spiaggia spiaggia) {
		super(nome, cognome, dataN, tel);
		this.spiaggia=spiaggia;
	}

	public Spiaggia getSpiaggia() {
		return this.spiaggia;
	}

	/**
	 * 
	 * @param spiaggia
	 */
	public void setSpiaggia(Spiaggia spiaggia) {
		this.spiaggia = spiaggia;
	}

	/**
	 * 
	 * @param nuovoRincaroStagione
	 */
	public void modificaRincaroStagione(float nuovoRincaroStagione) {
		// TODO - implement Gestore.modificaRincaroStagione
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nuovoRincaroCollocazione
	 */
	public void modificaRincaroCollocazione(float nuovoRincaroCollocazione) {
		// TODO - implement Gestore.modificaRincaroCollocazione
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nuovoOrarioApertura
	 */
	public void modificaOrarioApertura(String nuovoOrarioApertura) {
		// TODO - implement Gestore.modificaOrarioApertura
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param nuovoOrarioChiusura
	 */
	public void modificaOrarioChiusura(String nuovoOrarioChiusura) {
		// TODO - implement Gestore.modificaOrarioChiusura
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param attivita
	 */
	public void aggiungiAttivitaAListaAttivita(Attivita attivita) {
		// TODO - implement Gestore.aggiungiAttivitaAListaAttivita
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param attivita
	 */
	public void rimuoviAttivitaDaListaAttivita(Attivita attivita) {
		// TODO - implement Gestore.rimuoviAttivitaDaListaAttivita
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param promozione
	 */
	public void aggiungiPromozioneAListaPromozioni(Promozione promozione) {
		// TODO - implement Gestore.aggiungiPromozioneAListaPromozioni
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param promozione
	 */
	public void rimuoviPromozioneDaListaPromozioni(Promozione promozione) {
		// TODO - implement Gestore.rimuoviPromozioneDaListaPromozioni
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ombrellone
	 */
	public void aggiungiOmbrelloneAElencoOmbrelloni(Ombrellone ombrellone) {
		// TODO - implement Gestore.aggiungiOmbrelloneAElencoOmbrelloni
		throw new UnsupportedOperationException();
	}

	/**
	 * 
	 * @param ombrellone
	 */
	public void rimuoviOmbrelloneAElencoOmbrelloni(Ombrellone ombrellone) {
		// TODO - implement Gestore.rimuoviOmbrelloneAElencoOmbrelloni
		throw new UnsupportedOperationException();
	}

}