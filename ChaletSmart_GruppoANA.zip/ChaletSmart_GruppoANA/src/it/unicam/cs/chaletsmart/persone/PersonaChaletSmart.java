package it.unicam.cs.chaletsmart.persone;

import it.unicam.cs.chaletsmart.account.Account;

public class PersonaChaletSmart {

	private String nome;
	private String cognome;
	private String dataN;
	private String tel;
	private Account account;

	/**
	 * 
	 * @param nome
	 * @param cognome
	 * @param dataN
	 * @param tel
	 */
	public PersonaChaletSmart(String nome, String cognome, String dataN, String tel) {
		// TODO - implement PersonaChaletSmart.PersonaChaletSmart
		throw new UnsupportedOperationException();
	}

	public String getNome() {
		return this.nome;
	}

	/**
	 * 
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return this.cognome;
	}

	/**
	 * 
	 * @param cognome
	 */
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getDataN() {
		return this.dataN;
	}

	/**
	 * 
	 * @param dataN
	 */
	public void setDataN(String dataN) {
		this.dataN = dataN;
	}

	public String getTel() {
		return this.tel;
	}

	/**
	 * 
	 * @param tel
	 */
	public void setTel(String tel) {
		this.tel = tel;
	}

	public Account getAccount() {
		return this.account;
	}

	/**
	 * 
	 * @param account
	 */
	public void setAccount(Account account) {
		this.account = account;
	}

}