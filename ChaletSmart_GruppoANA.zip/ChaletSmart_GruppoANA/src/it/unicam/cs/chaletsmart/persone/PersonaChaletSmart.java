package it.unicam.cs.chaletsmart.persone;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import it.unicam.cs.chaletsmart.account.Account;

public class PersonaChaletSmart {


	private String nome;
	private String cognome;
	private String dataNascita;
	private String telefono;
	private Set<Account> account;

	/**
	 * 
	 * @param nome
	 * @param cognome
	 * @param dataN
	 * @param tel
	 */
	public PersonaChaletSmart(String nome, String cognome, String dataNascita, String telefono) {
		this.nome=nome;
		this.cognome=cognome;
		this.dataNascita=dataNascita;
		this.telefono=telefono;
		
		this.account=new HashSet<Account>();
	}

	public String getNome() {
		return this.nome;
	}

	/**
	 * 
	 * @param nome
	 */
	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCognome() {
		return this.cognome;
	}

	/**
	 * 
	 * @param cognome
	 */
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public String getDataN() {
		return this.dataNascita;
	}

	/**
	 * 
	 * @param dataN
	 */
	public void setDataN(String dataNascita) {
		this.dataNascita = dataNascita;
	}

	public String getTel() {
		return this.telefono;
	}

	/**
	 * 
	 * @param tel
	 */
	public void setTel(String telefono) {
		this.telefono = telefono;
	}

	public Account[] getAccount() {
		Account[] ritorno = new Account[this.account.size()];
		
		int contatore =0;
		for(Account a : this.account)
		{
			ritorno[contatore]=a;
			contatore++;
		}
		return ritorno;
	}
	
	public boolean rimuoviAccountSpecifico(Account account)
	{
		return this.account.remove(account);
	}

	/**
	 * 
	 * @param account
	 */
	public boolean aggiungiAccount(Account account) {
		return this.account.add(account);
	}
	

	@Override
	public int hashCode() {
		return Objects.hash(cognome, dataNascita, nome, telefono);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PersonaChaletSmart other = (PersonaChaletSmart) obj;
		return Objects.equals(cognome, other.cognome) && Objects.equals(dataNascita, other.dataNascita)
				&& Objects.equals(nome, other.nome) && Objects.equals(telefono, other.telefono);
	}

}