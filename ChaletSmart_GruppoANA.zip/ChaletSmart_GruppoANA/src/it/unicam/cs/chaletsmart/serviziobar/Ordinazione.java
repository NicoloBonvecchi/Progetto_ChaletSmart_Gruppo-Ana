package it.unicam.cs.chaletsmart.serviziobar;

import java.util.ArrayList;

import it.unicam.cs.chaletsmart.persone.Cliente;
import it.unicam.cs.chaletsmart.serviziospiaggia.*;

public class Ordinazione {

	private Cliente clienteOrdinante;
	private ArrayList<Prodotto> insiemeProdotti;
	private float costoComplessivo;
	private Ombrellone ombrelloneRelativo;

	/**
	 * 
	 * @param cliente
	 * @param ombrellone
	 */
	public Ordinazione(Cliente cliente, Ombrellone ombrellone) {
		this.clienteOrdinante=cliente;
		this.ombrelloneRelativo=ombrellone;
		this.costoComplessivo=0;
		this.insiemeProdotti=new ArrayList<Prodotto>();
	}

	public Cliente getClienteOrdinante() {
		return this.clienteOrdinante;
	}

	/**
	 * 
	 * @param clienteOrdinante
	 */
	public void setClienteOrdinante(Cliente clienteOrdinante) {
		this.clienteOrdinante = clienteOrdinante;
	}

	public float getCostoComplessivo() {
		float appCosto=0;
		for(Prodotto p : this.insiemeProdotti)
			appCosto+=p.getCosto();
		this.costoComplessivo=appCosto;
		return this.costoComplessivo;
	}

	/**
	 * 
	 * @param costoComplessivo
	 */
	public void setCostoComplessivo(float costoComplessivo) {
		this.costoComplessivo = costoComplessivo;
	}

	public Ombrellone getOmbrelloneRelativo() {
		return this.ombrelloneRelativo;
	}

	/**
	 * 
	 * @param ombrelloneRelativo
	 */
	public void setOmbrelloneRelativo(Ombrellone ombrelloneRelativo) {
		this.ombrelloneRelativo = ombrelloneRelativo;
	}

	/**
	 * 
	 * @param prodotto
	 * @param quantita
	 */
	public void aggiungiProdottiAdElencoProdotti(Prodotto prodotto, int quantita) {
		for(int i=0;i<quantita;i++)
		{
			insiemeProdotti.add(prodotto);
		}
	}
	
	public void aggiungiProdottoAdElencoProdotti(Prodotto prodotto) {
		insiemeProdotti.add(prodotto);
	}

	/**
	 * 
	 * @param prodotto
	 */
	public boolean rimuoviProdottoDaElencoProdotti(Prodotto prodotto) 
	{
		return insiemeProdotti.remove(prodotto);
	}
	
	public boolean rimuoviProdottiDaElencoProdottiPerTipo(Prodotto prodotto)
	{
		boolean trovato = false;
		for(Prodotto p : insiemeProdotti)
		{
			insiemeProdotti.remove(p);
			trovato=true;
		}
		return trovato;
	}

}