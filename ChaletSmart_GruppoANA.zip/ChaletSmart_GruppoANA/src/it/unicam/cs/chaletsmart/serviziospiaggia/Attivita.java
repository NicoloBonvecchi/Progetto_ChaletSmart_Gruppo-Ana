package it.unicam.cs.chaletsmart.serviziospiaggia;

import java.util.ArrayList;

import it.unicam.cs.chaletsmart.persone.Cliente;

public class Attivita {

	private String nomeIdentificativo;
	private int capienzaMax;
	private String orarioInizio;
	private String orarioFine;
	private String dataSvolgimento;
	private ArrayList<Cliente> partecipanti;

	/**
	 * 
	 * @param nomeIdentificativo
	 * @param capienzaMax
	 * @param orarioInizio
	 * @param orarioFine
	 * @param dataSvolgimento
	 */
	public Attivita(String nomeIdentificativo, int capienzaMax, String orarioInizio, String orarioFine, String dataSvolgimento) {
		this.nomeIdentificativo=nomeIdentificativo;
		this.capienzaMax=capienzaMax;
		this.orarioInizio=orarioInizio;
		this.orarioFine=orarioFine;
		this.partecipanti=new ArrayList<Cliente>();
	}

	public String getNomeIdentificativo() {
		return this.nomeIdentificativo;
	}

	/**
	 * 
	 * @param nomeIdentificativo
	 */
	public void setNomeIdentificativo(String nomeIdentificativo) {
		this.nomeIdentificativo = nomeIdentificativo;
	}

	public int getCapienzaMax() {
		return this.capienzaMax;
	}

	/**
	 * 
	 * @param capienzaMax
	 */
	public void setCapienzaMax(int capienzaMax) {
		this.capienzaMax = capienzaMax;
	}

	public String getOrarioInizio() {
		return this.orarioInizio;
	}

	/**
	 * 
	 * @param orarioInizio
	 */
	public void setOrarioInizio(String orarioInizio) {
		this.orarioInizio = orarioInizio;
	}

	public String getOrarioFine() {
		return this.orarioFine;
	}

	/**
	 * 
	 * @param orarioFine
	 */
	public void setOrarioFine(String orarioFine) {
		this.orarioFine = orarioFine;
	}

	public String getDataSvolgimento() {
		return this.dataSvolgimento;
	}

	/**
	 * 
	 * @param dataSvolgimento
	 */
	public void setDataSvolgimento(String dataSvolgimento) {
		this.dataSvolgimento = dataSvolgimento;
	}

	public ArrayList<Cliente> getPartecipanti() {
		return new ArrayList<>(this.partecipanti);
	}

	/**
	 * 
	 * @param partecipante
	 */
	public boolean aggiungiPartecipante(Cliente partecipante) {
		if(this.getPartecipanti().size()>=this.getCapienzaMax())
			return false;
		this.partecipanti.add(partecipante);
		return true;
	}

	/**
	 * 
	 * @param partecipante
	 */
	public boolean rimuoviPartecipante(Cliente partecipante) {
		return this.partecipanti.remove(partecipante);
	}

}