package it.unicam.cs.chaletsmart.serviziospiaggia;

import java.util.ArrayList;
import java.util.Arrays;

import it.unicam.cs.chaletsmart.persone.Cliente;

public class Prenotazione {

	private Cliente clientePrenotante;
	private TipoPrenotazione tipoPrenotazione;
	private ArrayList<Ombrellone> ombrelloniAssociati;
	private int lettiniAssociati;
	private float costoComplessivo;
	private String giornoDellaPrenotazione;
	private float rincaroStagione;


	private final float PREZZO_LETTINO=3;
	/**
	 * 
	 * @param cliente
	 * @param tipoPrenotazione
	 * @param ombrelloniAssociati
	 * @param lettiniAssociati
	 * @param giornoDellaPrenotazione
	 */
	public Prenotazione(Cliente cliente, TipoPrenotazione tipoPrenotazione, Ombrellone[] ombrelloniAssociati, int lettiniAssociati, String giornoDellaPrenotazione,float rincaroStagione) {
		this.clientePrenotante=cliente;
		this.tipoPrenotazione=tipoPrenotazione;
		this.lettiniAssociati=lettiniAssociati;
		this.giornoDellaPrenotazione=giornoDellaPrenotazione;
		this.ombrelloniAssociati=new ArrayList<Ombrellone>(Arrays.asList(ombrelloniAssociati));
		this.rincaroStagione=rincaroStagione;
	}

	public Cliente getClientePrenotante() {
		return this.clientePrenotante;
	}

	public TipoPrenotazione getTipoPrenotazione() {
		return this.tipoPrenotazione;
	}

	/**
	 * 
	 * @param tipoPrenotazione
	 */
	public void setTipoPrenotazione(TipoPrenotazione tipoPrenotazione) {
		this.tipoPrenotazione = tipoPrenotazione;
	}

	public Ombrellone[] getOmbrelloniAssociati() {
		return (Ombrellone[]) this.ombrelloniAssociati.toArray();
	}

	/**
	 * 
	 * @param ombrellone
	 */
	public void AggiungiOmbrellone(Ombrellone ombrellone) {
		this.ombrelloniAssociati.add(ombrellone);
	}

	/**
	 * 
	 * @param ombrellone
	 */
	public boolean RimuoviOmbrellone(Ombrellone ombrellone) {
		return this.ombrelloniAssociati.remove(ombrellone);
	}

	public int getLettiniAssociati() {
		return this.lettiniAssociati;
	}

	/**
	 * 
	 * @param lettiniAssociati
	 */
	public void setLettiniAssociati(int lettiniAssociati) {
		this.lettiniAssociati = lettiniAssociati;
	}

	public float getCostoComplessivo() {
		float appCosto=0;
		for(Ombrellone o: this.ombrelloniAssociati)
			appCosto+=o.getPrezzo()*o.getCollocazione().getRincaroCollocazione();
		costoComplessivo=appCosto+PREZZO_LETTINO*lettiniAssociati;
		return costoComplessivo;
	}

	public String getGiornoDellaPrenotazione() {
		return this.giornoDellaPrenotazione;
	}
	
	public float getPrezzoLettino()
	{
		return PREZZO_LETTINO;
	}
	
	public float getRincaroStagione() {
		return rincaroStagione;
	}

	public void setRincaroStagione(float rincaroStagione) {
		this.rincaroStagione = rincaroStagione;
	}


}