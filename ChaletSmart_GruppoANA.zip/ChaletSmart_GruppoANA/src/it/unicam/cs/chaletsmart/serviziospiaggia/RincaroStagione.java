package it.unicam.cs.chaletsmart.serviziospiaggia;

public enum RincaroStagione {
	
	MAGGIO(4,1f),
	GIUGNO(5,2f),
	LUGLIO(6,1f),
	AGOSTO(7,1f),
	SETTEMBRE(8,1f);
	
	private int mese;
	private float rincaro;
	
	RincaroStagione(int mese, float rincaro)
	{
		this.mese=mese;
		this.rincaro=rincaro;
	}

	public int getMese() {
		return mese;
	}

	public float getRincaro() {
		return rincaro;
	}

	public void setRincaro(float rincaro) {
		this.rincaro = rincaro;
	}
}
