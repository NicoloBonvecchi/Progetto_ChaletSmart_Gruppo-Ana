package it.unicam.cs.chaletsmart.serviziospiaggia;

import java.util.ArrayList;

import it.unicam.cs.chaletsmart.persone.*;

public class Spiaggia {

	/**
	 * Una tabella di associazioni che coinvolge gli ombrelloni.
	 * Nello specifico potrebbe essere un'associazione del tipo:
	 * identificativoOmbrellone, suaRelativaDisponibilit�.
	 */
	private ArrayList<Prenotazione> tabellaPrenotazioni;
	private String orarioApertura;
	private String orarioChiusura;
	private ArrayList<Attivita> listaAttivita;
	private ArrayList<Promozione> listaPromozioni;
	private ArrayList<Ombrellone> elencoOmbrelloni;

	/**
	 * 
	 * @param rincaroStagionale
	 * @param rincaroCollocazione
	 * @param orarioApertura
	 * @param orarioChiusura
	 */
	public Spiaggia(String orarioApertura, String orarioChiusura) {
		this.orarioApertura=orarioApertura;
		this.orarioChiusura=orarioChiusura;
		this.tabellaPrenotazioni=new ArrayList<Prenotazione>();
		this.listaAttivita=new ArrayList<Attivita>();
		this.listaPromozioni=new ArrayList<Promozione>();
		this.elencoOmbrelloni=new ArrayList<Ombrellone>();
	}

	public Prenotazione[] getTabellaPrenotazioni() {
		return (Prenotazione[]) this.tabellaPrenotazioni.toArray();
	}

	/**
	 * 
	 * @param prenotazione
	 */
	public void aggiungiPrenotazione(Prenotazione prenotazione) {
		this.tabellaPrenotazioni.add(prenotazione);
	}

	/**
	 * 
	 * @param prenotazione
	 */
	public boolean rimuoviPrenotazione(Prenotazione prenotazione) {
		return tabellaPrenotazioni.remove(prenotazione);
	}



	public String getOrarioApertura() {
		return this.orarioApertura;
	}

	/**
	 * 
	 * @param orarioApertura
	 */
	public void setOrarioApertura(String orarioApertura) {
		this.orarioApertura = orarioApertura;
	}

	public String getOrarioChiusura() {
		return this.orarioChiusura;
	}

	/**
	 * 
	 * @param orarioChiusura
	 */
	public void setOrarioChiusura(String orarioChiusura) {
		this.orarioChiusura = orarioChiusura;
	}

	public Attivita[] getListaAttivita() {
		return (Attivita[]) this.listaAttivita.toArray();
	}

	/**
	 * 
	 * @param attivita
	 */
	public void aggiungiAttivita(Attivita attivita) {
		this.listaAttivita.add(attivita);
	}

	/**
	 * 
	 * @param attivita
	 */
	public boolean rimuoviAttivita(Attivita attivita) {
		return listaAttivita.remove(attivita);
	}

	public Promozione[] getListaPromozioni() {
		return (Promozione[]) this.listaPromozioni.toArray();
	}

	/**
	 * 
	 * @param promozione
	 */
	public void aggiungiPromozione(Promozione promozione) {
		this.listaPromozioni.add(promozione);
	}

	/**
	 * 
	 * @param ombrellone
	 */
	public boolean rimuoviOmbrellone(Ombrellone ombrellone) {
		return elencoOmbrelloni.remove(ombrellone);
	}

	public Ombrellone[] getElencoOmbrelloni() {
		return (Ombrellone[]) this.elencoOmbrelloni.toArray();
	}

	/**
	 * 
	 * @param ombrellone
	 */
	public void aggiungiOmbrellone(Ombrellone ombrellone) {
		this.elencoOmbrelloni.add(ombrellone);
	}

	/**
	 * 
	 * @param promozione
	 */
	public boolean rimuoviPromozione(Promozione promozione) {
		return listaPromozioni.remove(promozione);
	}

	/**
	 * 
	 * @param cliente
	 * @param attivita
	 */
	public boolean aggiungiPrenotazioneAttivita(Cliente cliente, Attivita attivita) {
		if(attivita.getCapienzaMax()>=attivita.getPartecipanti().length)
			return false;
		attivita.aggiungiPartecipante(cliente);
		return true;
	}

	public boolean rimuoviPrenotazioneAttivita(Cliente cliente, Attivita attivita) {
		return attivita.rimuoviPartecipante(cliente);
	}

}