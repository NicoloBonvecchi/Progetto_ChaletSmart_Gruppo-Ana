package it.unicam.cs.chaletsmart.serviziospiaggia;

public enum TipoCollocazione {
	AVANTI(1.15f),
	INMEZZO(1.05f),
	DIETRO(1f);
	private float rincaroCollocazione;
	
	public float getRincaroCollocazione() {
		return rincaroCollocazione;
	}

	public void setRincaroCollocazione(float rincaroCollocazione) {
		this.rincaroCollocazione = rincaroCollocazione;
	}

	TipoCollocazione(float rincaroCollocazione)
	{
		this.rincaroCollocazione=rincaroCollocazione;
	}

}
