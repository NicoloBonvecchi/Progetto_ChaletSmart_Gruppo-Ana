package it.unicam.cs.chaletsmart.serviziospiaggia;

public enum TipoPrenotazione {
	MEZZAGIORNATA(0.6f),
	INTERO(1f),
	GIORNICONSECUTIVI(0.7f);

	private float percentualeSulCosto;

	TipoPrenotazione(float percentualeSulCosto)
	{
		this.percentualeSulCosto=percentualeSulCosto;
	}
	public float getPercentualeSulCosto() {
		return this.percentualeSulCosto;
	}

	/**
	 * 
	 * @param percentualeSulCosto
	 */
	public void setPercentualeSulCosto(float percentualeSulCosto) {
		this.percentualeSulCosto = percentualeSulCosto;
	}

}