package it.unicam.pizzeria4.sala;

public class TavoloAttivo {
	protected String ID;
	protected String idComanda;
	protected TipoTavoloAttivo stato; //Aggiunto per rappresentare il concetto in pagamento nell'iterazione 3

	public String getID() {
		return ID;
	}

	public void setID(String ID) {
		this.ID = ID;
	}

	public String getComanda() {
		return idComanda;
	}

	public void setComanda(String idComanda) {
		this.idComanda = idComanda;
	}
	
	public void setTipo(TipoTavoloAttivo stato) {
		this.stato = stato;
	}
	
	public TipoTavoloAttivo getTipo() {
		return stato;
	}
 }
