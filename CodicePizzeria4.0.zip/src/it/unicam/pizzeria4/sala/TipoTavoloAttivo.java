package it.unicam.pizzeria4.sala;

public enum TipoTavoloAttivo {
	standard,
	inpagamento,
	chiuso;
}
