package it.unicam.pizzeria4.cucina;

import java.util.ArrayList;

import it.unicam.pizzeria4.servizio.Portata;

public class GestorePreparazione {
	private static GestorePreparazione instance;

	private GestorePreparazione() {
		
	}
	/**
	 * 
	 * @param portate
	 */
	
	public static GestorePreparazione getInstance() {
		if (instance==null) {
			instance = new GestorePreparazione();
		}
		return instance;
	}
	
	
	public void inserisciCodaPreparazione(ArrayList<Portata> portate) {
		System.out.println("Portate inserite nella coda di preparazione");
	}

}
