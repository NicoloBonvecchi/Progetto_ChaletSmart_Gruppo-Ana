package it.unicam.pizzeria4.sala;

public class Tavolo {
	private String ID;
	private int capienza;
	private String sala;

	public Tavolo(String ID, int capienza) {
		this.capienza = capienza;
		this.ID = ID;
	}
	
	public String getID() {
		return ID;
	}

	public int getCapienza() {
		return capienza;	
	}
	
	public void setSala(String sala) {
		this.sala = sala;
	}
	
	public String getSala() {
		return sala;
	}


}
