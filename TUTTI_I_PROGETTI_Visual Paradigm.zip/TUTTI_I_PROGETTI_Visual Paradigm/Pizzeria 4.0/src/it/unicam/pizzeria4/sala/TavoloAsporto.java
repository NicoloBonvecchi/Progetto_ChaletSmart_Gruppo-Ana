package it.unicam.pizzeria4.sala;

public class TavoloAsporto extends TavoloAttivo {

}
