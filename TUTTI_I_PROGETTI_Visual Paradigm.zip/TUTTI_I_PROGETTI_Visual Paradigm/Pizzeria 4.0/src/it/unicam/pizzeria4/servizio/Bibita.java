package it.unicam.pizzeria4.servizio;

public class Bibita {
    private String ID;
	private String nome;
	private int quantita;
	private boolean isAlcolica;
	private String intolleranze;
	private String descrizione;
	private double prezzo;

	public Bibita(String ID, String nome, int quantita, boolean isAlcolica, String intolleranze, String descrizione) {
		super();
		this.ID = ID;
		this.nome = nome;
		this.quantita = quantita;
		this.isAlcolica = isAlcolica;
		this.intolleranze = intolleranze;
		this.descrizione = descrizione;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public String getID() {
		return ID;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getQuantita() {
		return quantita;
	}

	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}

	public boolean isAlcolica() {
		return isAlcolica;
	}

	public void setAlcolica(boolean isAlcolica) {
		this.isAlcolica = isAlcolica;
	}

	public String getIntolleranze() {
		return intolleranze;
	}

	public void setIntolleranze(String intolleranze) {
		this.intolleranze = intolleranze;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public void getDettagli() {
		// TODO - implement Bibita.getDettagli
		throw new UnsupportedOperationException();
	}

}
