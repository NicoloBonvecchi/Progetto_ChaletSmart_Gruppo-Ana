package it.unicam.pizzeria4.servizio;

import it.unicam.pizzeria4.util.Course;

public abstract class Ordinazione {

	public abstract String getID();

	public abstract String getNome();

	public abstract Course getTipo();

	public abstract double getPrezzo();

	public abstract String getIngredienti();

	public abstract String getIntolleranze();
	
	public abstract String getNote();

	public abstract int getQuantita();

	public abstract void setQuantita(int quantita);
}
