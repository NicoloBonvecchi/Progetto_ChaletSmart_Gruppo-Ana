package it.unicam.pizzeria4.servizio;

import it.unicam.pizzeria4.util.Course;

public class Piatto {

	private String ID;
	private String nome;
	private double prezzo;
	private String[] ingredienti;
	private Course tipo;
	private String intolleranze;
	

	public Piatto(String ID, String nome, String[] ingredienti, Course tipo, String intolleranze) {
		this.ID = ID;
		this.nome = nome;
		this.ingredienti = ingredienti;
		this.tipo = tipo;
		this.intolleranze = intolleranze;
	}
	
	public String getNome() {
		return nome;
	}

	public String getID() {
		return ID;
	}

	public Course getTipo() {
		return tipo;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}

	public void setID(String iD) {
		ID = iD;
	}

	public void setTipo(Course tipo) {
		this.tipo = tipo;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String[] getIngredienti() {
		return ingredienti;
	}

	public void setIngredienti(String[] ingredienti) {
		this.ingredienti = ingredienti;
	}

	public String getIntolleranze() {
		return intolleranze;
	}

	public void setIntolleranze(String intolleranze) {
		this.intolleranze = intolleranze;
	}

	public void getDettagli() {
		// TODO - implement Piatto.getDettagli
		throw new UnsupportedOperationException();
	}

}
