package it.unicam.pizzeria4.util;

public enum Course {
	antipasto,
	primo,
	secondo,
	contorno,
	dolce,
	bibitaAlcolica,
	bibitaAnalcolica
}
