package it.unicam.pizzeria4.util;

public class DatiPiatto {
	String ID;
	String nome;
	String[] ingredienti;
	int tipo;
	String intolleranze;
	double prezzo;
	

	public void setID(String iD) {
		ID = iD;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void setTipo(int tipo) {
		this.tipo = tipo;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}

	public String getID() {
		return ID;
	}

	public String getNome() {
		return nome;
	}

	public String[] getIngredienti() {
		return ingredienti;
	}

	public int getTipo() {
		return tipo;
	}

	public String getIntolleranze() {
		return intolleranze;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setIngredienti(String[] ingredienti) {
		this.ingredienti = ingredienti;
	}

	public void setIntolleranze(String intolleranze) {
		this.intolleranze = intolleranze;
	}

}
