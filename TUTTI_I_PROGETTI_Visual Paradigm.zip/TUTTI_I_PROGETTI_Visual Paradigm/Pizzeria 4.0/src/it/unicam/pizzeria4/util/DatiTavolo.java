package it.unicam.pizzeria4.util;

public class DatiTavolo {
	String codice;
	int capienza;
	String sala;
	
	public DatiTavolo(String codice, int capienza, String sala) {
		this.capienza = capienza;
		this.codice = codice;
		this.sala = sala;
	}

	public String getCodice() {
		return codice;
	}

	public int getCapienza() {
		return capienza;
	}

	public String getSala() {
		return sala;
	}

}
