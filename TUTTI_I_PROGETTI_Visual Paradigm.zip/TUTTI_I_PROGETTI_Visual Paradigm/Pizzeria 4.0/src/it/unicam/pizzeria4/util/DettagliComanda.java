package it.unicam.pizzeria4.util;

public class DettagliComanda {
	String idComanda;
	DettagliPortata[] dettagliPortata;
	
	public DettagliComanda(String idComanda, DettagliPortata[] dettagliPortata) {
		this.idComanda = idComanda;
		this.dettagliPortata = dettagliPortata;
	}
	
	public String getIdComanda() {
		return idComanda;
	}
	
	public DettagliPortata[] getDettagliPortata() {
		return dettagliPortata;
	}
}
