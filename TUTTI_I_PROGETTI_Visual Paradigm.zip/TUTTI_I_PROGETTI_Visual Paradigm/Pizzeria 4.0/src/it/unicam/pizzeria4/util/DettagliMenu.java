package it.unicam.pizzeria4.util;

public class DettagliMenu {
	private String ID;
	private String nome;
	private Course tipo;
	private double prezzo;
	private String descrizione;
	
	public DettagliMenu(String ID, String nome, Course tipo, double prezzo, String descrizione) {
		super();
		this.ID = ID;
		this.nome = nome;
		this.tipo = tipo;
		this.prezzo = prezzo;
		this.descrizione = descrizione;	
	}
	
	public double getPrezzo() {
		return prezzo;
	}

	public String getID() {
		return ID;
	}

	public String getNome() {
		return nome;
	}
	
	public Course getTipo() {
		return tipo;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	//Il metodo potrebbe generare un formato JSON
	public String toString() {
		return "ID:" + ID + "Nome:"+ nome+ "Tipo:" + tipo + "Prezzo:" + prezzo+ "Descrizione:" + descrizione;
	}
}
