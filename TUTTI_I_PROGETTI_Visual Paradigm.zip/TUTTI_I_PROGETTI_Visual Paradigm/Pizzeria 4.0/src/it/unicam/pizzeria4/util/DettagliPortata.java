package it.unicam.pizzeria4.util;

public class DettagliPortata {
	String note;
	int quantita;
	int ordine;
	
	public int getOrdine() {
		return ordine;
	}

	public void setOrdine(int ordine) {
		this.ordine = ordine;
	}

	public DettagliMenu getOrdinazione() {
		return ordinazione;
	}

	public void setOrdinazione(DettagliMenu ordinazione) {
		this.ordinazione = ordinazione;
	}

	DettagliMenu ordinazione;
	
	public String getNote() {
		return note;
	}

	public void setNote(String note) {
		this.note = note;
	}

	public int getQuantita() {
		return quantita;
	}

	public void setQuantita(int quantita) {
		this.quantita = quantita;
	}
}
