package it.unicam.pizzeria4.util;

public interface MenuObserver {

	public void update();

}
