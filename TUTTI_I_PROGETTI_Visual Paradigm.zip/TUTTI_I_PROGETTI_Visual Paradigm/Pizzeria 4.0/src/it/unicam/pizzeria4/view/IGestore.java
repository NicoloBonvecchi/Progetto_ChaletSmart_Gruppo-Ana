package it.unicam.pizzeria4.view;

import java.util.Scanner;

import it.unicam.pizzeria4.servizio.Menu;

public class IGestore {
	public static IGestore instance;
	
	Menu menu;

	private IGestore() {
		this.menu = Menu.getInstance();
	}
	
	public static IGestore getInstance() {
		if (instance == null) {
			instance = new IGestore();
		}
		return instance;
	}
	
	public void aggiornaMenu(Scanner reader) {
		System.out.println("[INFO]: Vuoi aggiornare il menù? Si prega di inserire l'identificativo del menù da caricare.");
		String idMenu = reader.nextLine();
		menu.scegliMenu(idMenu);
		System.out.println("[INFO]: Aggiornamento del Menu terminato.");
	}
}
