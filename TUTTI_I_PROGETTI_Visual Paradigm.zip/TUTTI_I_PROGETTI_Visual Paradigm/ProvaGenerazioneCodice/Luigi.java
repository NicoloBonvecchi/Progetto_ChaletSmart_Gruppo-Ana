public class Luigi {

	private Mario[] vettoreDiMario;

	public Mario[] getVettoreDiMario() {
		return this.vettoreDiMario;
	}

	/**
	 * 
	 * @param vettoreDiMario
	 */
	public void setVettoreDiMario(Mario[] vettoreDiMario) {
		this.vettoreDiMario = vettoreDiMario;
	}

}