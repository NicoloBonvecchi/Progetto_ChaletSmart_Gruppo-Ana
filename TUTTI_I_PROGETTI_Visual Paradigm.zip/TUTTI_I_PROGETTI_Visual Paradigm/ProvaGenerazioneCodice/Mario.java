public class Mario {

	private string itSAme;

	/**
	 * 
	 * @param peach
	 */
	public boolean bowser(int peach) {
		// TODO - implement Mario.bowser
		throw new UnsupportedOperationException();
	}

}