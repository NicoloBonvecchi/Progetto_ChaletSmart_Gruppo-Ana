public class Persona {

	private string nome;
	private int attribute;

	public string getNome() {
		return this.nome;
	}

	/**
	 * 
	 * @param nome
	 */
	public void setNome(string nome) {
		this.nome = nome;
	}

}