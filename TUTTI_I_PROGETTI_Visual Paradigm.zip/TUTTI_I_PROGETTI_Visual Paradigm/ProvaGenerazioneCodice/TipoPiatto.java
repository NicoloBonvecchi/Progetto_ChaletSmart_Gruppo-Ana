public class TipoPiatto {
	CONTORNO,
	PRIMOPIATTO,
	SECONDOPIATTO,
	DESSERT

	private string stringaAssociata;

	public string getStringaAssociata() {
		return this.stringaAssociata;
	}

	/**
	 * 
	 * @param stringaAssociata
	 */
	public void setStringaAssociata(string stringaAssociata) {
		this.stringaAssociata = stringaAssociata;
	}

}