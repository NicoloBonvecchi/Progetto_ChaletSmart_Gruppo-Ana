DROP TABLE IF EXISTS Prova CASCADE;
CREATE TYPE casaccio AS ENUM ('a', 'b', 'c');
CREATE TABLE Prova (
  id        SERIAL NOT NULL, 
  veritas   bool, 
  pantofole casaccio, 
  PRIMARY KEY (id));
