CREATE TYPE TipoAccountEnum AS ENUM ('Cliente','Addetto Prenotazioni','Addetto Attivita','Addetto Bar Cassa','Gestore');
;
CREATE TYPE TipoPrenotazioneEnum AS ENUM ('Mezza giornata','Intero');
;
CREATE TYPE TipoCollocazioneEnum AS ENUM ('Avanti','In mezzo','Dietro');
;
CREATE TYPE TipoMeseEnum AS ENUM ('5','6','7','8','9');
CREATE TABLE Account (
  ID          SERIAL NOT NULL, 
  nomeUtente  varchar(255) NOT NULL, 
  email       varchar(255) NOT NULL, 
  password    varchar(255) NOT NULL, 
  tipoAccount TipoAccountEnum NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE PersonaChaletSmart (
  ID          SERIAL NOT NULL, 
  nome        varchar(255) NOT NULL, 
  cognome     varchar(255) NOT NULL, 
  dataNascita varchar(255) NOT NULL, 
  telefono    varchar(255) NOT NULL, 
  AccountID   int4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE Prenotazione (
  ID                      SERIAL NOT NULL, 
  giornodellaPrenotazione timestamp NOT NULL, 
  aGiorniConsecutivi      bool NOT NULL, 
  lettiniAssociati        int4 DEFAULT 0 NOT NULL, 
  PersonaChaletSmartID    int4 NOT NULL, 
  TipoPrenotazioneID      int4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE Ombrellone (
  ID                 int4 NOT NULL, 
  prezzo             float4 DEFAULT 0 NOT NULL, 
  descrizione        varchar(255), 
  QRcode             varchar(255) NOT NULL, 
  categoria          int4 DEFAULT 0 NOT NULL, 
  PrenotazioneID     int4 NOT NULL, 
  TipoCollocazioneID int4 NOT NULL, 
  SpiaggiaID         int4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE Attivita (
  ID                 SERIAL NOT NULL, 
  nomeIdentificativo varchar(255) NOT NULL, 
  capienzaMax        int4 DEFAULT 0 NOT NULL, 
  orarioInizio       varchar(255) NOT NULL, 
  orarioFine         varchar(255) NOT NULL, 
  dataSvolgimento    varchar(255) NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE PrenotazioneAttivita (
  PersonaChaletSmartID int4 NOT NULL, 
  AttivitaID           int4 NOT NULL, 
  PRIMARY KEY (PersonaChaletSmartID, 
  AttivitaID));
CREATE TABLE Attrezzatura (
  ID                  SERIAL NOT NULL, 
  quantitaComplessiva int4 DEFAULT 0 NOT NULL, 
  descrizione         varchar(255), 
  PRIMARY KEY (ID));
CREATE TABLE PrenotazioneAttrezzatura (
  quantitaAttrezzaturaPrenotata int4 NOT NULL, 
  oraInizioPrenotazione         varchar(255) NOT NULL, 
  oraRestituzione               varchar(255), 
  PersonaChaletSmartID          int4 NOT NULL, 
  AttrezzaturaID                int4 NOT NULL, 
  PRIMARY KEY (quantitaAttrezzaturaPrenotata, 
  oraInizioPrenotazione, 
  PersonaChaletSmartID, 
  AttrezzaturaID));
CREATE TABLE Piatto (
  ID            int4 NOT NULL, 
  nome          varchar(255) NOT NULL, 
  descrizione   varchar(255), 
  isDisponibile bool NOT NULL, 
  costo         float4 NOT NULL, 
  ingredienti   varchar(255), 
  allergeni     varchar(255), 
  tipo          varchar(255), 
  PRIMARY KEY (ID));
CREATE TABLE Ordinazione (
  ID                   SERIAL NOT NULL, 
  costoComplessivo     float4 NOT NULL, 
  oraOrdinazione       timestamp NOT NULL, 
  OmbrelloniID         int4 NOT NULL, 
  PersonaChaletSmartID int4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE PiattoOrdinato (
  OrdinazioneID int4 NOT NULL, 
  PiattoID      int4 NOT NULL, 
  PRIMARY KEY (OrdinazioneID, 
  PiattoID));
CREATE TABLE Bibita (
  ID            int4 NOT NULL, 
  nome          varchar(255) NOT NULL, 
  descrizione   varchar(255), 
  isDisponibile bool NOT NULL, 
  costo         float4 NOT NULL, 
  isAlcolica    bool NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE BibitaOrdinata (
  OrdinazioneID int4 NOT NULL, 
  BibitaID      int4 NOT NULL, 
  PRIMARY KEY (OrdinazioneID, 
  BibitaID));
CREATE TABLE Menu (
  ID         SERIAL NOT NULL, 
  dataInizio varchar(255), 
  dataFine   varchar(255), 
  PRIMARY KEY (ID));
CREATE TABLE PiattoNelMenu (
  PiattoID int4 NOT NULL, 
  MenuID   int4 NOT NULL, 
  PRIMARY KEY (PiattoID, 
  MenuID));
CREATE TABLE BibitaNelMenu (
  BibitaID int4 NOT NULL, 
  MenuID   int4 NOT NULL, 
  PRIMARY KEY (BibitaID, 
  MenuID));
CREATE TABLE TipoPrenotazione (
  ID                  SERIAL NOT NULL, 
  stringaAssociata    TipoPrenotazioneEnum NOT NULL, 
  percentualeSulCosto float4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE TipoCollocazione (
  ID                  SERIAL NOT NULL, 
  stringaAssociata    TipoCollocazioneEnum NOT NULL, 
  rincaroCollocazione float4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE Spiaggia (
  ID                  SERIAL NOT NULL, 
  orarioApertura      varchar(255) NOT NULL, 
  orarioChiusura      varchar(255) NOT NULL, 
  capienzaMaxSpiaggia int4 NOT NULL, 
  prezzoLettino       float4 NOT NULL, 
  RincaroStagioneID   int4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE RincaroStagione (
  ID              SERIAL NOT NULL, 
  mese            TipoMeseEnum NOT NULL, 
  rincaroStagione float4 NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE NotificaEPromozione (
  ID                             SERIAL NOT NULL, 
  descrizioneNotificaOPromozione varchar(1000) NOT NULL, 
  PRIMARY KEY (ID));
CREATE TABLE NotificaEPromozioneAssociata (
  NotificheEPromozioniID int4 NOT NULL, 
  PersonaChaletSmartID   int4 NOT NULL, 
  PRIMARY KEY (NotificheEPromozioniID, 
  PersonaChaletSmartID));
ALTER TABLE Prenotazione ADD CONSTRAINT FKPrenotazio392368 FOREIGN KEY (PersonaChaletSmartID) REFERENCES PersonaChaletSmart (ID);
ALTER TABLE Ombrellone ADD CONSTRAINT FKOmbrellone322102 FOREIGN KEY (PrenotazioneID) REFERENCES Prenotazione (ID);
ALTER TABLE PrenotazioneAttivita ADD CONSTRAINT FKPrenotazio934853 FOREIGN KEY (PersonaChaletSmartID) REFERENCES PersonaChaletSmart (ID);
ALTER TABLE PrenotazioneAttivita ADD CONSTRAINT FKPrenotazio571165 FOREIGN KEY (AttivitaID) REFERENCES Attivita (ID);
ALTER TABLE PrenotazioneAttrezzatura ADD CONSTRAINT FKPrenotazio3938 FOREIGN KEY (PersonaChaletSmartID) REFERENCES PersonaChaletSmart (ID);
ALTER TABLE PrenotazioneAttrezzatura ADD CONSTRAINT FKPrenotazio437296 FOREIGN KEY (AttrezzaturaID) REFERENCES Attrezzatura (ID);
ALTER TABLE Ordinazione ADD CONSTRAINT FKOrdinazion604723 FOREIGN KEY (OmbrelloniID) REFERENCES Ombrellone (ID);
ALTER TABLE Ordinazione ADD CONSTRAINT FKOrdinazion334141 FOREIGN KEY (PersonaChaletSmartID) REFERENCES PersonaChaletSmart (ID);
ALTER TABLE PiattoOrdinato ADD CONSTRAINT FKPiattoOrdi839815 FOREIGN KEY (OrdinazioneID) REFERENCES Ordinazione (ID);
ALTER TABLE PiattoOrdinato ADD CONSTRAINT FKPiattoOrdi990284 FOREIGN KEY (PiattoID) REFERENCES Piatto (ID);
ALTER TABLE BibitaOrdinata ADD CONSTRAINT FKBibitaOrdi963887 FOREIGN KEY (OrdinazioneID) REFERENCES Ordinazione (ID);
ALTER TABLE BibitaOrdinata ADD CONSTRAINT FKBibitaOrdi729101 FOREIGN KEY (BibitaID) REFERENCES Bibita (ID);
ALTER TABLE PiattoNelMenu ADD CONSTRAINT FKPiattoNelM190372 FOREIGN KEY (PiattoID) REFERENCES Piatto (ID);
ALTER TABLE PiattoNelMenu ADD CONSTRAINT FKPiattoNelM157968 FOREIGN KEY (MenuID) REFERENCES Menu (ID);
ALTER TABLE BibitaNelMenu ADD CONSTRAINT FKBibitaNelM820454 FOREIGN KEY (BibitaID) REFERENCES Bibita (ID);
ALTER TABLE BibitaNelMenu ADD CONSTRAINT FKBibitaNelM980990 FOREIGN KEY (MenuID) REFERENCES Menu (ID);
ALTER TABLE Prenotazione ADD CONSTRAINT FKPrenotazio608596 FOREIGN KEY (TipoPrenotazioneID) REFERENCES TipoPrenotazione (ID);
ALTER TABLE Ombrellone ADD CONSTRAINT FKOmbrellone898161 FOREIGN KEY (TipoCollocazioneID) REFERENCES TipoCollocazione (ID);
ALTER TABLE Spiaggia ADD CONSTRAINT FKSpiaggia583285 FOREIGN KEY (RincaroStagioneID) REFERENCES RincaroStagione (ID);
ALTER TABLE NotificaEPromozioneAssociata ADD CONSTRAINT FKNotificaEP977082 FOREIGN KEY (NotificheEPromozioniID) REFERENCES NotificaEPromozione (ID);
ALTER TABLE NotificaEPromozioneAssociata ADD CONSTRAINT FKNotificaEP875439 FOREIGN KEY (PersonaChaletSmartID) REFERENCES PersonaChaletSmart (ID);
ALTER TABLE PersonaChaletSmart ADD CONSTRAINT FKPersonaCha610350 FOREIGN KEY (AccountID) REFERENCES Account (ID);
ALTER TABLE Ombrellone ADD CONSTRAINT FKOmbrellone825147 FOREIGN KEY (SpiaggiaID) REFERENCES Spiaggia (ID);
